package cs.colostate.cs414.g.domain;

public abstract class Employee {
	protected int employeeID ;
}
