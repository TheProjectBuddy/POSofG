package cs.colostate.cs414.g.util;

public enum Employee {
StoreManager,Cashier,Chef
}
