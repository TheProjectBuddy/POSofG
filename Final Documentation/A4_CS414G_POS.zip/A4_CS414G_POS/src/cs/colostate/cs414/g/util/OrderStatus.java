package cs.colostate.cs414.g.util;

public enum OrderStatus implements java.io.Serializable
{
	MODIFY,
	PREPARATION_WAITING,
	PREPARATION,
	COOKING_WAITING,
	COOKING,
	COMPLETED
}
