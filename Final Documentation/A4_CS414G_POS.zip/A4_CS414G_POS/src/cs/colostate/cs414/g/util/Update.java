package cs.colostate.cs414.g.util;

public interface Update {
	public void update();
}
